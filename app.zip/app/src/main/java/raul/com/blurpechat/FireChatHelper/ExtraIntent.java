package raul.com.blurpechat.FireChatHelper;

public final class ExtraIntent {
    public static final String EXTRA_CHAT_REF = "EXTRA_CHAT_REF";
    public static final String EXTRA_CURRENT_USER_ID = "EXTRA_CURRENT_USER_ID";
    public static final String EXTRA_RECIPIENT_ID = "EXTRA_RECIPIENT_ID";
}
